#!/usr/bin/env python3
"""Ubuntu Tutor prototype server.

No pip install is required: a pure-Python QR library is vendored in ./vendor.
This is a hackathon prototype, not a production identity/security service.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import os
import secrets
import socket
import sys
import threading
import time
import urllib.parse
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "database.json"
sys.path.insert(0, str(ROOT / "vendor"))

import qrcode
from qrcode.image.svg import SvgPathFillImage

SCHOOL_CODES = {
    "UBUNTU2026": "Ubuntu Demo School",
    "JHB001": "Johannesburg Future School",
    "GAUTENG10": "Gauteng Learning Lab",
}

DB_LOCK = threading.RLock()
SERVER_PORT = 8035


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def hash_password(password: str, salt_b64: str | None = None):
    if salt_b64:
        salt = base64.b64decode(salt_b64)
    else:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 180_000)
    return base64.b64encode(salt).decode(), base64.b64encode(digest).decode()


def verify_password(password, salt_b64, digest_b64):
    _, check = hash_password(password, salt_b64)
    return secrets.compare_digest(check, digest_b64)


def new_analytics(seed=0):
    presets = [
        dict(progress=58, streak=6, confidence=62, algebra=82, factorisation=61, signs=44, quadratics=58, gap="Negative-number sign errors", status="Priority"),
        dict(progress=61, streak=3, confidence=70, algebra=74, factorisation=66, signs=49, quadratics=61, gap="Negative-number operations", status="Monitor"),
        dict(progress=64, streak=4, confidence=72, algebra=77, factorisation=57, signs=68, quadratics=64, gap="Factorisation concept", status="Monitor"),
        dict(progress=83, streak=9, confidence=88, algebra=91, factorisation=84, signs=82, quadratics=83, gap="Improving", status="On track"),
    ]
    p = presets[seed % len(presets)]
    return {
        "progress": p["progress"], "streak": p["streak"], "confidence": p["confidence"],
        "skills": {"algebra":p["algebra"], "factorisation":p["factorisation"], "signs":p["signs"], "quadratics":p["quadratics"]},
        "misconceptions": [
            {"title":p["gap"], "count": 3 if seed==0 else 2, "severity":"high" if seed==0 else "medium"},
            {"title":"Low confidence on correct answers", "count":1, "severity":"low"},
        ],
        "main_gap":p["gap"], "status":p["status"], "offline_packs":1 if seed % 2 == 0 else 2,
        "last_sync":"Today" if seed % 2 == 0 else "Yesterday",
        "activity":[
            {"date":"Today", "title":"Adaptive practice completed", "detail":"Quadratic equations session updated the Learning Fingerprint."},
            {"date":"Yesterday", "title":"Ubuntu Offline used", "detail":"Completed a lesson from the downloaded Mathematics pack."},
            {"date":"2 days ago", "title":"Teach Ubuntu completed", "detail":"Explained factorisation in own words."},
        ]
    }


def public_user(user):
    result = {k:v for k,v in user.items() if k not in {"password_hash","salt"}}
    return result


def load_db():
    DATA_DIR.mkdir(exist_ok=True)
    if not DB_PATH.exists():
        db = {"users":{}, "sessions":{}, "created_at":now_iso()}
        save_db(db)
        return db
    try:
        return json.loads(DB_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"users":{}, "sessions":{}, "created_at":now_iso()}


def save_db(db):
    DATA_DIR.mkdir(exist_ok=True)
    tmp = DB_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(db, indent=2), encoding="utf-8")
    tmp.replace(DB_PATH)


def add_user(db, *, role, name, email, password, grade=None, school_code=None, teacher_id=None, teacher_code=None, analytics=None, user_id=None):
    salt, ph = hash_password(password)
    uid = user_id or ("t_" if role=="teacher" else "l_") + secrets.token_hex(5)
    user = {
        "id":uid, "role":role, "name":name.strip(), "email":email.strip().lower(),
        "salt":salt, "password_hash":ph, "created_at":now_iso(),
    }
    if role == "teacher":
        user.update({"school_code":school_code, "school_name":SCHOOL_CODES.get(school_code,"School"), "teacher_code": teacher_code or "TCH-"+secrets.token_hex(3).upper()})
    else:
        user.update({"grade":int(grade or 10), "teacher_id":teacher_id, "analytics":analytics or new_analytics()})
    db["users"][uid] = user
    return user


def seed_db():
    with DB_LOCK:
        db=load_db()
        if any(u.get("email")=="teacher@ubuntu.demo" for u in db["users"].values()):
            return
        teacher=add_user(db, role="teacher", name="Ms N. Dlamini", email="teacher@ubuntu.demo", password="Teacher123!", school_code="UBUNTU2026", teacher_code="TCH-DEMO01", user_id="t_demo")
        students=[
            ("Lerato M.","learner@ubuntu.demo","Learner123!"),
            ("Sipho K.","sipho@ubuntu.demo","Learner123!"),
            ("Nandi P.","nandi@ubuntu.demo","Learner123!"),
            ("Thabo R.","thabo@ubuntu.demo","Learner123!"),
        ]
        for i,(name,email,pw) in enumerate(students):
            add_user(db, role="learner", name=name, email=email, password=pw, grade=10, teacher_id=teacher["id"], analytics=new_analytics(i), user_id=f"l_demo_{i+1}")
        save_db(db)


def find_by_email(db,email):
    email=email.strip().lower()
    return next((u for u in db["users"].values() if u.get("email")==email),None)


def find_teacher_by_code(db, code):
    c=(code or "").strip().upper()
    return next((u for u in db["users"].values() if u.get("role")=="teacher" and u.get("teacher_code")==c),None)


def get_auth_user(db, headers, query=None):
    token=None
    auth=headers.get("Authorization","")
    if auth.startswith("Bearer "):
        token=auth[7:].strip()
    if not token and query:
        token=query.get("token",[None])[0]
    uid=db.get("sessions",{}).get(token)
    return db["users"].get(uid), token


def make_session(db,user):
    token=secrets.token_urlsafe(32)
    db.setdefault("sessions",{})[token]=user["id"]
    return token


class Handler(SimpleHTTPRequestHandler):
    server_version="UbuntuTutorPrototype/5.0"

    def translate_path(self, path):
        # Serve strictly from project root.
        parsed=urllib.parse.urlparse(path).path
        rel=urllib.parse.unquote(parsed).lstrip('/') or 'index.html'
        candidate=(ROOT/rel).resolve()
        if ROOT not in candidate.parents and candidate != ROOT:
            return str(ROOT/'index.html')
        return str(candidate)

    def log_message(self, fmt, *args):
        print("[Ubuntu Tutor]", fmt % args)

    def _json(self, status, payload):
        data=json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.send_header("Cache-Control","no-store")
        self.end_headers(); self.wfile.write(data)

    def _body(self):
        try:
            length=int(self.headers.get("Content-Length","0") or 0)
            if length>1_000_000: raise ValueError("Request too large")
            raw=self.rfile.read(length) if length else b"{}"
            return json.loads(raw.decode() or "{}")
        except Exception:
            return None

    def _query(self):
        return urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

    def do_GET(self):
        parsed=urllib.parse.urlparse(self.path)
        path=parsed.path
        q=urllib.parse.parse_qs(parsed.query)
        if path.startswith('/api/'):
            return self.handle_api_get(path,q)
        return super().do_GET()

    def do_POST(self):
        path=urllib.parse.urlparse(self.path).path
        if not path.startswith('/api/'):
            return self._json(404,{"error":"Not found"})
        body=self._body()
        if body is None: return self._json(400,{"error":"Invalid JSON"})
        return self.handle_api_post(path,body)

    def handle_api_get(self,path,q):
        with DB_LOCK:
            db=load_db()
            if path=='/api/config':
                lan=f"http://{local_ip()}:{SERVER_PORT}"
                return self._json(200,{"app":"Ubuntu Tutor","version":"5.0","lan_url":lan,"school_demo_code":"UBUNTU2026","demo_accounts":{"teacher":{"email":"teacher@ubuntu.demo","password":"Teacher123!"},"learner":{"email":"learner@ubuntu.demo","password":"Learner123!"}}})

            if path=='/api/session':
                user,token=get_auth_user(db,self.headers,q)
                if not user: return self._json(401,{"error":"Session expired"})
                return self._json(200,{"user":public_user(user)})

            if path=='/api/teacher/lookup':
                teacher=find_teacher_by_code(db,q.get('code',[''])[0])
                if not teacher: return self._json(404,{"error":"Teacher code not found"})
                return self._json(200,{"teacher":{"id":teacher['id'],"name":teacher['name'],"school_name":teacher['school_name'],"teacher_code":teacher['teacher_code']}})

            if path=='/api/learner/teacher':
                user,_=get_auth_user(db,self.headers,q)
                if not user or user.get('role')!='learner': return self._json(401,{"error":"Learner sign-in required"})
                teacher=db['users'].get(user.get('teacher_id')) if user.get('teacher_id') else None
                return self._json(200,{"teacher": public_user(teacher) if teacher else None})

            if path=='/api/teacher/students':
                user,_=get_auth_user(db,self.headers,q)
                if not user or user.get('role')!='teacher': return self._json(401,{"error":"Teacher sign-in required"})
                students=[]
                for s in db['users'].values():
                    if s.get('role')=='learner' and s.get('teacher_id')==user['id']:
                        a=s.get('analytics',new_analytics())
                        students.append({"id":s['id'],"name":s['name'],"email":s['email'],"grade":s.get('grade',10),"progress":a.get('progress',0),"confidence":a.get('confidence',0),"main_gap":a.get('main_gap','No major gap'),"status":a.get('status','Monitor'),"last_sync":a.get('last_sync','—')})
                students.sort(key=lambda x:x['name'])
                avg=round(sum(x['progress'] for x in students)/len(students)) if students else 0
                priority=sum(1 for x in students if x['status']=='Priority')
                return self._json(200,{"teacher":public_user(user),"students":students,"stats":{"count":len(students),"average":avg,"priority":priority,"offline":sum(1 for s in db['users'].values() if s.get('role')=='learner' and s.get('teacher_id')==user['id'] and s.get('analytics',{}).get('offline_packs',0)>0)}})

            if path.startswith('/api/teacher/student/'):
                user,_=get_auth_user(db,self.headers,q)
                if not user or user.get('role')!='teacher': return self._json(401,{"error":"Teacher sign-in required"})
                sid=path.rsplit('/',1)[-1]
                student=db['users'].get(sid)
                if not student or student.get('role')!='learner' or student.get('teacher_id')!=user['id']:
                    return self._json(404,{"error":"Student not found for this teacher"})
                return self._json(200,{"student":public_user(student),"analytics":student.get('analytics',new_analytics())})

            if path=='/api/teacher/qr.svg':
                user,_=get_auth_user(db,self.headers,q)
                if not user or user.get('role')!='teacher': return self._json(401,{"error":"Teacher sign-in required"})
                join_url=f"http://{local_ip()}:{SERVER_PORT}/?join={urllib.parse.quote(user['teacher_code'])}"
                qr=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=3)
                qr.add_data(join_url); qr.make(fit=True)
                img=qr.make_image(image_factory=SvgPathFillImage)
                bio=io.BytesIO(); img.save(bio)
                data=bio.getvalue()
                self.send_response(200)
                self.send_header('Content-Type','image/svg+xml; charset=utf-8')
                self.send_header('Content-Length',str(len(data)))
                self.send_header('Cache-Control','no-store')
                self.end_headers(); self.wfile.write(data); return

            return self._json(404,{"error":"API endpoint not found"})

    def handle_api_post(self,path,body):
        with DB_LOCK:
            db=load_db()
            if path=='/api/login':
                email=str(body.get('email','')).strip().lower(); pw=str(body.get('password','')); role=body.get('role')
                user=find_by_email(db,email)
                if not user or user.get('role')!=role or not verify_password(pw,user['salt'],user['password_hash']):
                    return self._json(401,{"error":"Incorrect email, password, or account type"})
                token=make_session(db,user); save_db(db)
                return self._json(200,{"token":token,"user":public_user(user)})

            if path=='/api/register/teacher':
                name=str(body.get('name','')).strip(); email=str(body.get('email','')).strip().lower(); pw=str(body.get('password','')); code=str(body.get('school_code','')).strip().upper()
                if not all([name,email,pw,code]): return self._json(400,{"error":"All teacher registration fields are required"})
                if code not in SCHOOL_CODES: return self._json(400,{"error":"School code is not recognised"})
                if len(pw)<8: return self._json(400,{"error":"Password must be at least 8 characters"})
                if find_by_email(db,email): return self._json(409,{"error":"An account with this email already exists"})
                user=add_user(db,role='teacher',name=name,email=email,password=pw,school_code=code)
                token=make_session(db,user); save_db(db)
                return self._json(201,{"token":token,"user":public_user(user)})

            if path=='/api/register/learner':
                name=str(body.get('name','')).strip(); email=str(body.get('email','')).strip().lower(); pw=str(body.get('password','')); grade=body.get('grade',10); tcode=str(body.get('teacher_code','')).strip().upper()
                if not all([name,email,pw]): return self._json(400,{"error":"Name, email and password are required"})
                if len(pw)<8: return self._json(400,{"error":"Password must be at least 8 characters"})
                if find_by_email(db,email): return self._json(409,{"error":"An account with this email already exists"})
                teacher=None
                if tcode:
                    teacher=find_teacher_by_code(db,tcode)
                    if not teacher: return self._json(400,{"error":"Teacher code is not valid"})
                user=add_user(db,role='learner',name=name,email=email,password=pw,grade=grade,teacher_id=teacher['id'] if teacher else None,analytics=new_analytics(1))
                token=make_session(db,user); save_db(db)
                return self._json(201,{"token":token,"user":public_user(user),"teacher":public_user(teacher) if teacher else None})

            if path=='/api/logout':
                user,token=get_auth_user(db,self.headers)
                if token and token in db.get('sessions',{}): db['sessions'].pop(token,None); save_db(db)
                return self._json(200,{"ok":True})

            if path=='/api/link-teacher':
                user,_=get_auth_user(db,self.headers)
                if not user or user.get('role')!='learner': return self._json(401,{"error":"Learner sign-in required"})
                teacher=find_teacher_by_code(db,str(body.get('teacher_code','')).strip().upper())
                if not teacher: return self._json(404,{"error":"Teacher code not found"})
                if user.get('teacher_id') and user['teacher_id']!=teacher['id']:
                    return self._json(409,{"error":"This learner is already linked to another teacher"})
                user['teacher_id']=teacher['id']; save_db(db)
                return self._json(200,{"teacher":public_user(teacher),"user":public_user(user)})

            if path=='/api/teacher/students':
                teacher,_=get_auth_user(db,self.headers)
                if not teacher or teacher.get('role')!='teacher': return self._json(401,{"error":"Teacher sign-in required"})
                name=str(body.get('name','')).strip(); email=str(body.get('email','')).strip().lower(); grade=body.get('grade',10); pw=str(body.get('password','')).strip() or ("Ubuntu"+str(secrets.randbelow(9000)+1000)+"!")
                if not name or not email: return self._json(400,{"error":"Student name and email are required"})
                existing=find_by_email(db,email)
                created=False
                if existing:
                    if existing.get('role')!='learner': return self._json(409,{"error":"That email belongs to a teacher account"})
                    if existing.get('teacher_id') and existing.get('teacher_id')!=teacher['id']:
                        return self._json(409,{"error":"That learner is already linked to another teacher"})
                    existing['teacher_id']=teacher['id']; student=existing
                else:
                    student=add_user(db,role='learner',name=name,email=email,password=pw,grade=grade,teacher_id=teacher['id'],analytics=new_analytics(secrets.randbelow(4)))
                    created=True
                save_db(db)
                return self._json(201,{"student":public_user(student),"created":created,"temporary_password":pw if created else None})

            if path=='/api/progress':
                learner,_=get_auth_user(db,self.headers)
                if not learner or learner.get('role')!='learner': return self._json(401,{"error":"Learner sign-in required"})
                analytics=learner.setdefault('analytics',new_analytics())
                metrics=body.get('metrics') or {}
                if metrics:
                    analytics['skills']={
                        'algebra':int(metrics.get('algebra',analytics['skills'].get('algebra',0))),
                        'factorisation':int(metrics.get('factorisation',analytics['skills'].get('factorisation',0))),
                        'signs':int(metrics.get('signs',analytics['skills'].get('signs',0))),
                        'quadratics':int(metrics.get('quadratics',analytics['skills'].get('quadratics',0))),
                    }
                    analytics['confidence']=int(metrics.get('confidenceAlignment',analytics.get('confidence',0)))
                    analytics['progress']=round(sum(analytics['skills'].values())/4)
                if isinstance(body.get('misconceptions'),list):
                    analytics['misconceptions']=[{"title":str(x.get('title','Learning pattern')),"count":int(x.get('count',1)),"severity":str(x.get('severity','medium'))} for x in body['misconceptions'][:8]]
                    if analytics['misconceptions']: analytics['main_gap']=analytics['misconceptions'][0]['title']
                activity=body.get('activity')
                if isinstance(activity,list) and activity:
                    analytics['activity']=activity[:8]
                analytics['last_sync']='Just now'
                analytics['status']='Priority' if analytics.get('progress',0)<60 else ('Monitor' if analytics.get('progress',0)<75 else 'On track')
                save_db(db)
                return self._json(200,{"ok":True,"analytics":analytics})

            return self._json(404,{"error":"API endpoint not found"})


def main():
    global SERVER_PORT
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8020)
    parser.add_argument('--host',default='0.0.0.0')
    args=parser.parse_args(); SERVER_PORT=args.port
    os.chdir(ROOT)
    seed_db()
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    lan=f"http://{local_ip()}:{args.port}"
    print("\nUbuntu Tutor V5 is running")
    print(f"  This computer: http://localhost:{args.port}")
    print(f"  Same Wi-Fi devices: {lan}")
    print("\nDemo teacher: teacher@ubuntu.demo / Teacher123!")
    print("Demo learner: learner@ubuntu.demo / Learner123!")
    print("Teacher registration school code: UBUNTU2026\n")
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nStopping Ubuntu Tutor...")
    finally: server.server_close()

if __name__=='__main__': main()

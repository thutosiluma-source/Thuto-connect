(() => {
  "use strict";
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const SESSION_KEY="ubuntuTutorSessionV6";
  const PROGRESS_QUEUE_KEY="ubuntuTutorProgressQueueV6";
  const joinFromUrl = new URLSearchParams(location.search).get("join") || "";

  const Auth = {
    token: localStorage.getItem(SESSION_KEY) || "",
    user: null,
    config: null,
    pendingJoinCode: joinFromUrl,
    teacherStudents: [],
    selectedStudentId: null,

    async api(path, options={}){
      const headers={"Content-Type":"application/json", ...(options.headers||{})};
      if(this.token) headers.Authorization=`Bearer ${this.token}`;
      const res=await fetch(path,{...options,headers});
      const type=res.headers.get("content-type")||"";
      const body=type.includes("application/json") ? await res.json() : await res.text();
      if(!res.ok) throw new Error(body?.error || `Request failed (${res.status})`);
      return body;
    },

    async init(){
      try{ this.config=await this.api("/api/config"); }catch{}
      this.bindAuthUI();
      this.applyConfigHints();
      if(this.token){
        try{
          const data=await this.api("/api/session");
          this.user=data.user;
          this.showApp();
          return;
        }catch{ this.clearSession(false); }
      }
      this.showAuth();
      if(joinFromUrl) this.prepareJoinRegistration(joinFromUrl);
    },

    applyConfigHints(){
      if(!this.config) return;
      const el=$("#demoSchoolCode"); if(el) el.textContent=this.config.school_demo_code;
      $("#demoTeacherEmail") && ($("#demoTeacherEmail").textContent=this.config.demo_accounts.teacher.email);
      $("#demoTeacherPassword") && ($("#demoTeacherPassword").textContent=this.config.demo_accounts.teacher.password);
      $("#demoLearnerEmail") && ($("#demoLearnerEmail").textContent=this.config.demo_accounts.learner.email);
      $("#demoLearnerPassword") && ($("#demoLearnerPassword").textContent=this.config.demo_accounts.learner.password);
    },

    bindAuthUI(){
      $$("[data-auth-role]").forEach(b=>b.addEventListener("click",()=>this.setRole(b.dataset.authRole)));
      $$("[data-auth-mode]").forEach(b=>b.addEventListener("click",()=>this.setMode(b.dataset.authMode)));
      $("#authForm")?.addEventListener("submit",e=>this.submitAuth(e));
      $("#demoLearnerBtn")?.addEventListener("click",()=>this.demoLogin("learner"));
      $("#demoTeacherBtn")?.addEventListener("click",()=>this.demoLogin("teacher"));
      $("#copyTeacherCodeBtn")?.addEventListener("click",()=>this.copyTeacherCode());
      $("#signOutBtn")?.addEventListener("click",()=>this.logout());
      $("#scanTeacherQrBtn")?.addEventListener("click",()=>this.openScanner("register"));
      $("#linkTeacherBtn")?.addEventListener("click",()=>this.openLinkTeacher());
      $("#linkTeacherForm")?.addEventListener("submit",e=>this.submitLinkTeacher(e));
      $("#scanLinkQrBtn")?.addEventListener("click",()=>this.openScanner("link"));
      $("#scannerCloseBtn")?.addEventListener("click",()=>this.closeScanner());
      $("#addStudentBtn")?.addEventListener("click",()=>this.openAddStudent());
      $("#addStudentForm")?.addEventListener("submit",e=>this.addStudent(e));
      $("#teacherStudentSearch")?.addEventListener("input",()=>this.renderStudentList());
      $("#copyTeacherJoinLinkBtn")?.addEventListener("click",()=>this.copyJoinLink());
      $("#refreshTeacherDataBtn")?.addEventListener("click",()=>this.loadTeacherDashboard(true));
      window.addEventListener("online",()=>this.flushProgressQueue());
      window.addEventListener("ubuntu-app-ready",()=>this.applyRoleUI());
    },

    async demoLogin(role){
      if(!this.config) return;
      this.setRole(role); this.setMode("signin");
      const demo=this.config.demo_accounts[role];
      $("#authEmail").value=demo.email; $("#authPassword").value=demo.password;
      $("#authForm").requestSubmit();
    },

    async copyTeacherCode(){
      const code=this.user?.teacher_code || $("#teacherCodeLabel")?.textContent || "";
      if(!code) return;
      try{ await navigator.clipboard.writeText(code); window.UbuntuToast?.("Teacher code copied."); }
      catch{ window.UbuntuToast?.(code); }
    },

    setRole(role){
      $("#authRole").value=role;
      $$("[data-auth-role]").forEach(b=>b.classList.toggle("active",b.dataset.authRole===role));
      this.updateAuthFields();
    },
    setMode(mode){
      $("#authMode").value=mode;
      $$("[data-auth-mode]").forEach(b=>b.classList.toggle("active",b.dataset.authMode===mode));
      this.updateAuthFields();
    },
    updateAuthFields(){
      const role=$("#authRole").value, mode=$("#authMode").value;
      $("#authSubmitBtn").textContent=mode==="signin"?`Sign in as ${role}`:`Create ${role} account`;
      $("#registrationFields").classList.toggle("hidden",mode!=="register");
      $("#teacherRegisterFields").classList.toggle("hidden",!(mode==="register"&&role==="teacher"));
      $("#learnerRegisterFields").classList.toggle("hidden",!(mode==="register"&&role==="learner"));
      $("#authName").required=mode==="register";
      $("#schoolCode").required=mode==="register"&&role==="teacher";
      $("#authIntro").textContent = role==="teacher"
        ? (mode==="signin"?"Sign in to manage your learners and view individual analytics.":"Teachers need a valid school code before creating a classroom account.")
        : (mode==="signin"?"Sign in to continue your personalised learning path.":"Learn independently or link yourself to a teacher now or later.");
    },

    async submitAuth(e){
      e.preventDefault(); this.setAuthError("");
      const role=$("#authRole").value, mode=$("#authMode").value;
      const btn=$("#authSubmitBtn"); btn.disabled=true; btn.textContent="Please wait…";
      try{
        let data;
        if(mode==="signin"){
          data=await this.api("/api/login",{method:"POST",body:JSON.stringify({role,email:$("#authEmail").value,password:$("#authPassword").value})});
        }else if(role==="teacher"){
          data=await this.api("/api/register/teacher",{method:"POST",body:JSON.stringify({name:$("#authName").value,email:$("#authEmail").value,password:$("#authPassword").value,school_code:$("#schoolCode").value})});
        }else{
          data=await this.api("/api/register/learner",{method:"POST",body:JSON.stringify({name:$("#authName").value,email:$("#authEmail").value,password:$("#authPassword").value,grade:$("#learnerGrade").value,teacher_code:$("#teacherCodeInput").value})});
        }
        this.token=data.token; this.user=data.user; localStorage.setItem(SESSION_KEY,this.token);
        history.replaceState({},"",location.pathname);
        this.showApp();
      }catch(err){ this.setAuthError(err.message); }
      finally{btn.disabled=false;this.updateAuthFields();}
    },

    setAuthError(msg){ const el=$("#authError"); el.textContent=msg; el.classList.toggle("hidden",!msg); },
    showAuth(){ $("#authScreen").classList.remove("hidden"); $("#appShell").classList.add("hidden"); },
    showApp(){
      $("#authScreen").classList.add("hidden"); $("#appShell").classList.remove("hidden");
      document.body.dataset.role=this.user.role;
      this.applyRoleUI(); this.flushProgressQueue();
      if(this.user.role==="learner" && this.pendingJoinCode) this.linkTeacherCode(this.pendingJoinCode,true);
    },
    clearSession(show=true){this.token="";this.user=null;localStorage.removeItem(SESSION_KEY);if(show)this.showAuth();},
    async logout(){ try{await this.api("/api/logout",{method:"POST",body:"{}"});}catch{} this.clearSession(); history.replaceState({},"",location.pathname); },

    prepareJoinRegistration(code){
      this.setRole("learner");this.setMode("register");$("#teacherCodeInput").value=code;
      const note=$("#joinTeacherNotice");note.classList.remove("hidden");note.textContent=`Teacher QR detected: ${code}. Create your learner account to join this teacher.`;
    },

    applyRoleUI(){
      if(!this.user || !window.UbuntuNavigate) return;
      const teacher=this.user.role==="teacher";
      $$(".nav-item").forEach(b=>{
        if(teacher) b.classList.toggle("role-hidden",!b.classList.contains("teacher-nav"));
        else b.classList.toggle("role-hidden",b.classList.contains("teacher-nav"));
      });
      $(".bottom-nav")?.classList.toggle("role-hidden",teacher);
      $("#switchProfileBtn")?.classList.toggle("role-hidden",teacher);
      $("#sidebarName").textContent=this.user.name;
      $("#sidebarAvatar").textContent=this.initials(this.user.name);
      $("#headerName").textContent=this.user.name.split(" ")[0];
      $("#headerAvatar").textContent=this.initials(this.user.name);
      const meta=$("#sidebarRoleMeta");
      if(meta) meta.textContent=teacher?`${this.user.school_name} • Teacher`:`Grade ${this.user.grade||10} • ${this.user.teacher_id?"Teacher linked":"Independent"}`;
      if(teacher){ window.UbuntuNavigate("teacher"); this.loadTeacherDashboard(); }
      else {
        window.UbuntuSetLearnerGrade?.(this.user.grade || 10);
        window.UbuntuNavigate("home");
        this.loadLearnerTeacherStatus();
      }
    },
    initials(name){return String(name||"U").split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase();},

    async loadLearnerTeacherStatus(){
      if(!this.user || this.user.role!=="learner")return;
      try{
        const data=await this.api("/api/learner/teacher");
        const card=$("#learnerTeacherCard"); if(!card)return;
        if(data.teacher){
          card.classList.add("linked");
          $("#learnerTeacherStatusTitle").textContent=`Connected to ${data.teacher.name}`;
          $("#learnerTeacherStatusText").textContent=`${data.teacher.school_name} • Your teacher can view your learning analytics and progress.`;
          $("#linkTeacherBtn").textContent="Teacher connected ✓"; $("#linkTeacherBtn").disabled=true;
          this.user.teacher_id=data.teacher.id;
        }else{
          card.classList.remove("linked");
          $("#learnerTeacherStatusTitle").textContent="Learning independently";
          $("#learnerTeacherStatusText").textContent="You can use Ubuntu Tutor without a teacher. Link later with a teacher code or QR if you want your teacher to see your analytics.";
          $("#linkTeacherBtn").textContent="Join a teacher"; $("#linkTeacherBtn").disabled=false;
        }
      }catch{}
    },

    openLinkTeacher(){ $("#linkTeacherCode").value=""; $("#linkTeacherResult").classList.add("hidden"); window.openUbuntuModal("linkTeacherModal"); },
    async submitLinkTeacher(e){e.preventDefault();await this.linkTeacherCode($("#linkTeacherCode").value,false);},
    async linkTeacherCode(code,fromQr=false){
      if(!code)return;
      try{
        const data=await this.api("/api/link-teacher",{method:"POST",body:JSON.stringify({teacher_code:code})});
        this.user=data.user; this.pendingJoinCode=""; history.replaceState({},"",location.pathname);
        window.closeUbuntuModal?.("linkTeacherModal"); this.loadLearnerTeacherStatus();
        window.UbuntuToast?.(`Connected to ${data.teacher.name}.`);
      }catch(err){
        if(fromQr) window.UbuntuToast?.(err.message); else {const r=$("#linkTeacherResult");r.textContent=err.message;r.classList.remove("hidden");}
      }
    },

    async loadTeacherDashboard(force=false){
      if(!this.user || this.user.role!=="teacher")return;
      try{
        const data=await this.api("/api/teacher/students");
        this.teacherStudents=data.students; this.user=data.teacher;
        $("#teacherWelcomeName").textContent=this.user.name;
        $("#teacherSchoolName").textContent=this.user.school_name;
        $("#teacherCodeLabel").textContent=this.user.teacher_code;
        $("#teacherStudentCount").textContent=data.stats.count;
        $("#teacherClassAverage").textContent=`${data.stats.average}%`;
        $("#teacherPriorityCount").textContent=data.stats.priority;
        $("#teacherOfflineCount").textContent=data.stats.offline;
        $("#teacherQrImage").src=`/api/teacher/qr.svg?token=${encodeURIComponent(this.token)}&v=${Date.now()}`;
        if(this.config?.lan_url){ const lan=$("#teacherLanUrl"), link=$("#teacherJoinLink"); if(lan) lan.textContent=this.config.lan_url; if(link) link.value=`${this.config.lan_url}/?join=${encodeURIComponent(this.user.teacher_code)}`; }
        this.renderStudentList();
        if(!this.selectedStudentId && data.students.length)this.selectedStudentId=data.students[0].id;
        if(this.selectedStudentId && data.students.some(s=>s.id===this.selectedStudentId)) this.selectStudent(this.selectedStudentId);
        else this.renderEmptyAnalytics();
        if(force) window.UbuntuToast?.("Teacher dashboard refreshed.");
      }catch(err){window.UbuntuToast?.(err.message);}
    },

    renderStudentList(){
      const list=$("#teacherStudentList"); if(!list)return;
      const term=($("#teacherStudentSearch")?.value||"").toLowerCase();
      const students=this.teacherStudents.filter(s=>`${s.name} ${s.email} ${s.main_gap}`.toLowerCase().includes(term));
      if(!students.length){list.innerHTML=`<div class="empty-state">No learners match this search.</div>`;return;}
      list.innerHTML="";
      students.forEach(s=>{
        const b=document.createElement("button"); b.className="student-select-card"+(s.id===this.selectedStudentId?" active":"");
        const statusClass=s.status==="Priority"?"danger":s.status==="On track"?"success":"warn";
        b.innerHTML=`<div class="avatar small">${this.initials(s.name)}</div><div class="student-select-main"><strong>${this.esc(s.name)}</strong><span>${this.esc(s.main_gap)}</span></div><div class="student-select-score"><strong>${s.progress}%</strong><span class="status ${statusClass}">${s.status}</span></div>`;
        b.addEventListener("click",()=>this.selectStudent(s.id));list.appendChild(b);
      });
    },

    async selectStudent(id){
      this.selectedStudentId=id; this.renderStudentList();
      const panel=$("#studentAnalyticsPanel"); panel.innerHTML=`<div class="analytics-loading">Loading learner analytics…</div>`;
      try{
        const data=await this.api(`/api/teacher/student/${encodeURIComponent(id)}`);
        this.renderStudentAnalytics(data.student,data.analytics);
      }catch(err){panel.innerHTML=`<div class="empty-state">${this.esc(err.message)}</div>`;}
    },

    renderEmptyAnalytics(){ $("#studentAnalyticsPanel").innerHTML=`<div class="analytics-empty"><div>👤</div><h3>Select a learner</h3><p>Choose a learner from the roster to view their Learning Fingerprint, confidence, gaps and recent activity.</p></div>`; },
    renderStudentAnalytics(s,a){
      const skills=a.skills||{};
      const gaps=(a.misconceptions||[]).map(x=>`<div class="student-gap-item"><div><strong>${this.esc(x.title)}</strong><span>Detected ${x.count||1} time${(x.count||1)===1?"":"s"}</span></div><span class="status ${x.severity==="high"?"danger":"warn"}">${x.severity||"medium"}</span></div>`).join("") || `<div class="empty-state">No major gaps detected.</div>`;
      const activity=(a.activity||[]).map(x=>`<div class="mini-activity"><i></i><div><strong>${this.esc(x.title)}</strong><span>${this.esc(x.date)} • ${this.esc(x.detail)}</span></div></div>`).join("");
      const skill=(label,key)=>`<div class="teacher-skill-row"><div><strong>${label}</strong><span>${skills[key]||0}%</span></div><div class="teacher-skill-bar"><i style="width:${skills[key]||0}%"></i></div></div>`;
      $("#studentAnalyticsPanel").innerHTML=`
        <div class="student-analytics-head"><div class="student-big-avatar">${this.initials(s.name)}</div><div><span class="kicker dark">INDIVIDUAL ANALYTICS</span><h2>${this.esc(s.name)}</h2><p>Grade ${s.grade||10} • ${this.esc(s.email)}</p></div><div class="student-overall"><strong>${a.progress||0}%</strong><span>overall</span></div></div>
        <div class="individual-stat-grid"><div><strong>${a.confidence||0}%</strong><span>Confidence alignment</span></div><div><strong>${a.streak||0} days</strong><span>Learning streak</span></div><div><strong>${a.offline_packs||0}</strong><span>Offline packs</span></div><div><strong>${this.esc(a.last_sync||"—")}</strong><span>Last sync</span></div></div>
        <div class="student-analytics-grid"><section><span class="kicker dark">LEARNING FINGERPRINT</span><h3>Skill mastery</h3>${skill("Basic algebra","algebra")}${skill("Factorisation","factorisation")}${skill("Sign handling","signs")}${skill("Quadratic equations","quadratics")}</section><section><span class="kicker dark">LEARNING GAPS</span><h3>What needs attention</h3><div class="student-gap-list">${gaps}</div></section></div>
        <div class="student-activity-section"><span class="kicker dark">RECENT ACTIVITY</span><h3>Learning timeline</h3>${activity}</div>`;
    },

    openAddStudent(){ $("#addStudentForm").reset(); $("#addStudentResult").classList.add("hidden"); window.openUbuntuModal("addStudentModal"); },
    async addStudent(e){
      e.preventDefault();const btn=$("#addStudentSubmitBtn");btn.disabled=true;btn.textContent="Adding…";
      try{
        const data=await this.api("/api/teacher/students",{method:"POST",body:JSON.stringify({name:$("#addStudentName").value,email:$("#addStudentEmail").value,grade:$("#addStudentGrade").value,password:$("#addStudentPassword").value})});
        const r=$("#addStudentResult");r.classList.remove("hidden");
        r.innerHTML=data.created?`<b>Student created and linked.</b><br>Temporary password: <strong>${this.esc(data.temporary_password)}</strong><br><small>Give this to the learner so they can sign in and change it in a production version.</small>`:`<b>Existing learner linked successfully.</b>`;
        await this.loadTeacherDashboard();
      }catch(err){const r=$("#addStudentResult");r.textContent=err.message;r.classList.remove("hidden");}
      finally{btn.disabled=false;btn.textContent="Add student";}
    },

    async copyJoinLink(){
      const text=$("#teacherJoinLink").value;
      try{await navigator.clipboard.writeText(text);window.UbuntuToast?.("Teacher join link copied.");}
      catch{$("#teacherJoinLink").select();document.execCommand("copy");window.UbuntuToast?.("Teacher join link copied.");}
    },

    scannerStream:null, scannerTimer:null, scannerMode:"register",
    async openScanner(mode){
      this.scannerMode=mode;window.openUbuntuModal("scannerModal");$("#scannerStatus").textContent="Starting camera…";
      if(!navigator.mediaDevices?.getUserMedia){$("#scannerStatus").textContent="Camera access is unavailable. Use the teacher code instead.";return;}
      if(!("BarcodeDetector" in window)){$("#scannerStatus").textContent="This browser cannot scan QR codes inside the page. Use your phone's Camera app to scan the teacher QR, or enter the teacher code manually.";return;}
      try{
        this.scannerStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}},audio:false});
        const video=$("#qrScannerVideo");video.srcObject=this.scannerStream;await video.play();$("#scannerStatus").textContent="Point the camera at the teacher's Ubuntu Tutor QR code.";
        const detector=new BarcodeDetector({formats:["qr_code"]});
        const scan=async()=>{
          if(!this.scannerStream)return;
          try{const codes=await detector.detect(video);if(codes.length){const code=this.extractTeacherCode(codes[0].rawValue);if(code){this.closeScanner();this.acceptScannedCode(code);return;}}}catch{}
          this.scannerTimer=requestAnimationFrame(scan);
        };scan();
      }catch(err){$("#scannerStatus").textContent="Camera permission failed. You can still enter the teacher code manually.";}
    },
    extractTeacherCode(raw){try{const u=new URL(raw);return u.searchParams.get("join")||"";}catch{}const m=String(raw).match(/TCH-[A-Z0-9-]+/i);return m?m[0].toUpperCase():"";},
    acceptScannedCode(code){if(this.scannerMode==="register"){$("#teacherCodeInput").value=code;$("#joinTeacherNotice").classList.remove("hidden");$("#joinTeacherNotice").textContent=`Teacher QR scanned: ${code}`;}else{$("#linkTeacherCode").value=code;this.linkTeacherCode(code,false);}window.UbuntuToast?.("Teacher QR recognised.");},
    closeScanner(){if(this.scannerTimer)cancelAnimationFrame(this.scannerTimer);this.scannerTimer=null;if(this.scannerStream){this.scannerStream.getTracks().forEach(t=>t.stop());this.scannerStream=null;}$("#qrScannerVideo").srcObject=null;window.closeUbuntuModal?.("scannerModal");},

    async recordProgress(payload){
      if(!this.user || this.user.role!=="learner")return;
      const offline=payload.offline || !navigator.onLine;
      if(offline){
        const q=JSON.parse(localStorage.getItem(PROGRESS_QUEUE_KEY)||"[]");q.push(payload);localStorage.setItem(PROGRESS_QUEUE_KEY,JSON.stringify(q));return;
      }
      try{await this.api("/api/progress",{method:"POST",body:JSON.stringify(payload)});}catch{const q=JSON.parse(localStorage.getItem(PROGRESS_QUEUE_KEY)||"[]");q.push(payload);localStorage.setItem(PROGRESS_QUEUE_KEY,JSON.stringify(q));}
    },
    async flushProgressQueue(){
      if(!this.user || this.user.role!=="learner" || !navigator.onLine)return;
      let q=JSON.parse(localStorage.getItem(PROGRESS_QUEUE_KEY)||"[]");if(!q.length)return;
      const remain=[];for(const item of q){try{await this.api("/api/progress",{method:"POST",body:JSON.stringify(item)});}catch{remain.push(item);}}
      localStorage.setItem(PROGRESS_QUEUE_KEY,JSON.stringify(remain));if(!remain.length)window.UbuntuToast?.("Offline learning progress synced to your teacher analytics.");
    },
    esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  };

  window.UbuntuAuth=Auth;
  Auth.init();
})();

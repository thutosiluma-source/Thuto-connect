#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Starting Ubuntu Tutor at http://localhost:8035"
python3 server.py --port 8035

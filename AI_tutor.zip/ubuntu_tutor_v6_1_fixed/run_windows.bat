@echo off
cd /d "%~dp0"
echo.
echo Starting Ubuntu Tutor...
echo Open http://localhost:8035 in your browser.
echo Keep this window open while using the app.
echo.
python server.py --port 8035
pause

(() => {
  "use strict";

  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];

  const STORAGE_KEY = "ubuntuTutorLearningV6";

  const defaultState = {
    activeProfileId: "lerato",
    profiles: [
      {id:"lerato", name:"Lerato M.", short:"Lerato", initials:"LM", grade:10, progress:68, streak:6},
      {id:"sipho", name:"Sipho K.", short:"Sipho", initials:"SK", grade:10, progress:61, streak:3}
    ],
    bridgeLanguage: "en",
    tutorMode: "guided",
    selectedGrade: 10,
    selectedTopic: "quadratics",
    forceOffline: false,
    dataSaver: false,
    packs: [],
    queue: [],
    syncQueue: [],
    activity: [
      {date:"Today", title:"Learning Fingerprint updated", detail:"Sign-error pattern detected during quadratics practice."},
      {date:"Yesterday", title:"Offline pack used", detail:"Completed 12 minutes of Mathematics with no connection."},
      {date:"2 days ago", title:"Teach Ubuntu completed", detail:"Explained factorisation with partial mastery."}
    ],
    metrics: {
      algebra:82,
      factorisation:61,
      signs:44,
      quadratics:58,
      confidenceAlignment:62
    },
    misconceptions: [
      {key:"signs", title:"Negative-number sign errors", detail:"Repeated mistakes when a negative sign changes during factorisation.", count:3, severity:"high"},
      {key:"sumProduct", title:"Sum vs product confusion", detail:"Occasional confusion between numbers that add and numbers that multiply.", count:1, severity:"medium"}
    ],
    practiceHistory: []
  };

  function clone(x){ return JSON.parse(JSON.stringify(x)); }
  function loadState(){
    try{
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return stored ? {...clone(defaultState), ...stored, metrics:{...defaultState.metrics,...(stored.metrics||{})}} : clone(defaultState);
    }catch{ return clone(defaultState); }
  }
  let state = loadState();
  if(!Number(state.selectedGrade)) state.selectedGrade = 10;
  if(!state.selectedTopic) state.selectedTopic = "quadratics";

  function save(){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    updateGlobalUI();
  }

  function isOffline(){
    return state.forceOffline || !navigator.onLine;
  }

  function currentProfile(){
    return state.profiles.find(p => p.id === state.activeProfileId) || state.profiles[0];
  }

  function initials(name){
    return name.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase();
  }

  function toast(message){
    const t = $("#toast");
    t.textContent = message;
    t.classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(()=>t.classList.remove("show"), 2500);
  }

  const pageTitles = {
    home:"Home", tutor:"Ubuntu Tutor", practice:"Practice",
    offline:"Ubuntu Offline", progress:"My Progress", teacher:"Teacher View"
  };

  function navigate(page){
    $$(".page").forEach(p=>p.classList.toggle("active", p.id === `page-${page}`));
    $$(".nav-item, .bottom-nav button").forEach(b=>b.classList.toggle("active", b.dataset.page === page));
    $("#pageTitle").textContent = pageTitles[page] || page;
    $("#sidebar").classList.remove("open");
    window.scrollTo({top:0,behavior:"smooth"});
    if(page === "progress") renderProgress();
    if(page === "offline") renderPacks();
  }

  window.UbuntuNavigate = navigate;
  window.UbuntuToast = toast;
  window.openUbuntuModal = openModal;
  window.closeUbuntuModal = closeModal;

  $$(".nav-item, .bottom-nav button").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
  $$("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
  $("#mobileMenuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));

  function updateGlobalUI(){
    const p = currentProfile();
    $("#sidebarName").textContent = p.name;
    $("#sidebarAvatar").textContent = p.initials;
    $("#headerName").textContent = p.short;
    $("#headerAvatar").textContent = p.initials;
    $("#homeProgress").textContent = `${p.progress}%`;
    $("#homeStreak").textContent = `${p.streak} days`;
    $("#homeOfflineCount").textContent = state.packs.length;

    const off = isOffline();
    const np = $("#networkPill");
    np.classList.toggle("offline", off);
    $("#networkText").textContent = off ? "Ubuntu Offline • No data" : "Ubuntu AI • Online";

    const pending = state.syncQueue.length + state.queue.length;
    $("#syncPill").classList.toggle("pending", pending > 0);
    $("#syncText").textContent = pending ? `${pending} pending` : "Synced";
    $("#queuedCount").textContent = `${state.queue.length} question${state.queue.length===1?"":"s"} waiting`;
    $("#offlineTutorHint").textContent = off
      ? "Using your saved learning material."
      : "Ready to help with your selected topic.";

    $("#bridgeLanguage").value = state.bridgeLanguage;
    $("#tutorMode").value = state.tutorMode;
    $("#forceOfflineToggle").checked = state.forceOffline;
    $("#dataSaverToggle").checked = state.dataSaver;

    updateOfflineBanner();
  }

  function queueSync(type, payload={}){
    state.syncQueue.push({id:Date.now()+Math.random(), type, payload, createdAt:new Date().toISOString()});
    save();
  }

  function trySync(){
    if(isOffline()) return;
    if(!state.syncQueue.length && !state.queue.length) return;

    const queuedQuestions = state.queue.splice(0);
    state.syncQueue = [];
    queuedQuestions.forEach(q=>{
      state.activity.unshift({
        date:"Just now",
        title:"Queued question synchronised",
        detail:`"${q.text.slice(0,70)}${q.text.length>70?"…":""}" was saved and is ready to continue.`
      });
    });
    save();
    renderQueue();
    toast("You’re back online — your saved work is up to date.");
  }

  window.addEventListener("online",()=>{updateGlobalUI();trySync();});
  window.addEventListener("offline",()=>{updateGlobalUI();toast("Ubuntu Offline activated.");});

  // Profiles / shared-device mode
  function renderProfiles(){
    const list = $("#profileList");
    list.innerHTML = "";
    state.profiles.forEach(p=>{
      const btn = document.createElement("button");
      btn.className = "profile-option" + (p.id===state.activeProfileId ? " active":"");
      btn.innerHTML = `<div class="avatar">${p.initials}</div><div><strong>${p.name}</strong><span>Grade ${p.grade} • ${p.progress}% term progress</span></div>`;
      btn.addEventListener("click",()=>{
        state.activeProfileId = p.id;
        save();
        renderProfiles();
        closeModal("profileModal");
        renderProgress();
        toast(`Switched to ${p.short}'s learning profile.`);
      });
      list.appendChild(btn);
    });
  }
  function openModal(id){ $(`#${id}`).classList.remove("hidden"); }
  function closeModal(id){ $(`#${id}`).classList.add("hidden"); }
  $("#switchProfileBtn").addEventListener("click",()=>{renderProfiles();openModal("profileModal")});
  $("#profileButton").addEventListener("click",()=>{renderProfiles();openModal("profileModal")});
  $$("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
  $$(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m) closeModal(m.id)}));
  $("#addDemoProfileBtn").addEventListener("click",()=>{
    const idx = state.profiles.length+1;
    const name = `Demo Learner ${idx}`;
    const id = `demo${Date.now()}`;
    state.profiles.push({id,name,short:`Learner ${idx}`,initials:initials(name),grade:10,progress:50,streak:1});
    save();renderProfiles();toast("Demo learner added to shared-device mode.");
  });

  // Mathematics learning-library tutor
  let mathDataset = null;
  let lastAIText = "";
  let datasetReady = null;

  function currentGradeData(){
    if(!mathDataset) return null;
    return mathDataset.grades.find(g => Number(g.grade) === Number(state.selectedGrade)) || mathDataset.grades[0];
  }

  function currentTopicData(){
    const grade = currentGradeData();
    return grade?.topics.find(t => t.id === state.selectedTopic) || grade?.topics[0] || null;
  }

  async function loadMathDataset(){
    try{
      if(window.UBUNTU_MATH_DATASET){
        mathDataset = window.UBUNTU_MATH_DATASET;
      }else{
        const res = await fetch("./data/math_dataset.json", {cache:"no-store"});
        if(!res.ok) throw new Error("Learning material could not be loaded.");
        mathDataset = await res.json();
      }

      const signedInGrade = Number(window.UbuntuAuth?.user?.grade || 0);
      if(signedInGrade && mathDataset.grades.some(g=>g.grade===signedInGrade)){
        state.selectedGrade = signedInGrade;
      }
      if(!mathDataset.grades.some(g=>Number(g.grade)===Number(state.selectedGrade))){
        state.selectedGrade = mathDataset.grades[0].grade;
      }
      populateStudySelectors();
      updateStudyContext(false);
      return true;
    }catch(err){
      console.error("Ubuntu Tutor dataset error:", err);
      const mode=$("#chatModeText"), title=$("#topicPreviewTitle"), summary=$("#topicPreviewSummary");
      if(mode) mode.textContent = "Mathematics";
      if(title) title.textContent = "Learning material unavailable";
      if(summary) summary.textContent = "Refresh Ubuntu Tutor and try again.";
      return false;
    }
  }

  function populateStudySelectors(){
    const gradeSelect = $("#studyGrade");
    if(!gradeSelect || !mathDataset) return;
    gradeSelect.innerHTML = mathDataset.grades.map(g=>`<option value="${g.grade}">Grade ${g.grade}</option>`).join("");
    gradeSelect.value = String(state.selectedGrade);
    populateTopicSelector();
  }

  function populateTopicSelector(){
    const grade = currentGradeData();
    const topicSelect = $("#studyTopic");
    if(!grade || !topicSelect) return;
    if(!grade.topics.some(t=>t.id===state.selectedTopic)) state.selectedTopic = grade.topics[0].id;
    topicSelect.innerHTML = grade.topics.map(t=>`<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("");
    topicSelect.value = state.selectedTopic;
  }

  function updateStudyContext(announce=true){
    const topic = currentTopicData();
    if(!topic) return;
    save();
    $("#studyGrade").value = String(state.selectedGrade);
    $("#studyTopic").value = state.selectedTopic;
    $("#chatModeText").textContent = `Grade ${state.selectedGrade} Mathematics • ${topic.name}`;
    $("#chatInput").placeholder = `Ask a Grade ${state.selectedGrade} question about ${topic.name}...`;
    $("#topicPreviewTitle").textContent = topic.name;
    $("#topicPreviewSummary").textContent = topic.overview;
    $("#topicKeyIdeas").innerHTML = topic.key_rules.slice(0,4).map(x=>`<li>${escapeHtml(x)}</li>`).join("");
    $("#topicMistakes").innerHTML = topic.common_mistakes.slice(0,3).map(x=>`<li>${escapeHtml(x)}</li>`).join("");
    renderPromptChips(topic);
    if(announce && $("#chatWindow").children.length){
      addMessage("ai", `You’re now studying ${topic.name}. Ask me anything about this topic.`, `Grade ${state.selectedGrade} Mathematics • ${topic.name}`);
    }
  }

  function renderPromptChips(topic){
    const el = $("#promptChips");
    if(!el) return;
    el.innerHTML = "";
    (topic.suggested_questions || []).slice(0,4).forEach(text=>{
      const b=document.createElement("button");
      b.type="button";
      b.textContent=text;
      b.addEventListener("click",()=>sendChat(text));
      el.appendChild(b);
    });
  }

  function addMessage(role, text, source=""){
    const win = $("#chatWindow");
    const row = document.createElement("div");
    row.className = `message ${role}`;
    if(role === "ai"){
      row.innerHTML = `<div class="tiny-avatar">U</div><div class="bubble"><div class="message-text"></div>${source?`<small class="message-source">${escapeHtml(source)}</small>`:""}</div>`;
      row.querySelector(".message-text").textContent = text;
    }else{
      row.innerHTML = `<div class="bubble"><div class="message-text"></div></div>`;
      row.querySelector(".message-text").textContent = text;
    }
    win.appendChild(row);
    win.scrollTop = win.scrollHeight;
    if(role==="ai") lastAIText = text;
  }

  function tokenise(text){
    return String(text).toLowerCase()
      .replace(/[^\p{L}\p{N}²^+\-=/().]/gu," ")
      .split(/\s+/).filter(x=>x.length>1);
  }

  function overlapScore(a,b){
    const A=new Set(tokenise(a)), B=new Set(tokenise(b));
    let score=0;
    A.forEach(x=>{ if(B.has(x)) score++; });
    return score;
  }

  function closestExample(topic, question){
    const examples = topic.worked_examples || [];
    if(!examples.length) return null;
    return [...examples].sort((a,b)=>overlapScore(question,b.question)-overlapScore(question,a.question))[0];
  }

  function bridgeNote(topic){
    if(state.bridgeLanguage==="zu"){
      return `\n\nUbuntu Bridge: Uma ufuna, ngingakuchazela lesi sihloko nge-English + isiZulu. Key Mathematics terms such as "${topic.name}" stay in English so you recognise them in assessments.`;
    }
    if(state.bridgeLanguage==="nr"){
      return `\n\nUbuntu Bridge: Ngingahlathulula lesi sihloko nge-English + isiNdebele. Key Mathematics terms such as "${topic.name}" stay in English ukuze uzijayele eemhlolweni.`;
    }
    return "";
  }

  function formatExample(ex){
    if(!ex) return "";
    return `${ex.question}\n${ex.steps.map((s,i)=>`${i+1}. ${s}`).join("\n")}\nAnswer: ${ex.answer}`;
  }

  function tutorResponseFromDataset(question){
    const topic = currentTopicData();
    if(!topic) return {text:"Choose a grade and topic first.", local:false, source:"Mathematics"};

    const q = question.toLowerCase();
    const source = `Grade ${state.selectedGrade} Mathematics • ${topic.name}`;
    const wantsPractice = /(practice|quiz|test me|question to try|give me a question)/.test(q);
    const wantsHint = state.tutorMode==="hint" || /(hint|clue|help me start)/.test(q);
    const wantsMistakes = /(mistake|wrong|confus|struggl|common error|why do i keep)/.test(q);
    const wantsRules = /(formula|rule|law|steps|method|how do i)/.test(q);
    const wantsExample = /(example|show me|solve|calculate|work out|factorise|factorize|find)/.test(q);
    const example = closestExample(topic, question);

    let text = "";

    if(wantsPractice){
      text = `Try this:\n\n${topic.practice_question}\n\n${wantsHint ? `Hint: ${topic.practice_hint}` : "Have a go first. If you get stuck, ask me for a hint."}`;
    }else if(wantsMistakes){
      text = `A common difficulty in ${topic.name} is:\n\n• ${topic.common_mistakes.join("\n• ")}\n\nFor your next attempt, slow down at the step where the sign, rule or operation changes.`;
    }else if(wantsHint){
      text = `Hint: ${topic.practice_hint}\n\nKey idea: ${topic.key_rules[0]}`;
    }else if(wantsExample && example){
      if(state.tutorMode==="guided"){
        text = `${topic.overview}\n\nLet’s use a worked example:\n${formatExample(example)}\n\nNow try: ${topic.practice_question}`;
      }else if(state.tutorMode==="revision"){
        text = `${topic.overview}\n\nRemember:\n• ${topic.key_rules.slice(0,3).join("\n• ")}\n\nExample answer: ${example.answer}`;
      }else{
        text = `Start with this idea: ${topic.key_rules[0]}\n\nHint for a similar question: ${topic.practice_hint}`;
      }
    }else if(wantsRules){
      text = `${topic.overview}\n\nKey rules:\n• ${topic.key_rules.join("\n• ")}\n\nTry this afterwards: ${topic.practice_question}`;
    }else{
      text = `${topic.overview}\n\nKey ideas:\n• ${topic.key_rules.slice(0,3).join("\n• ")}\n\nExample:\n${formatExample(example)}\n\nYou can ask me to explain a step, give you a hint, or give you a practice question.`;
    }

    text += bridgeNote(topic);
    if(isOffline()) text += `\n\n📵 This topic is available from your saved learning material.`;
    return {text, local:true, source};
  }

  async function initChat(){
    await datasetReady;
    if($("#chatWindow").children.length) return;
    const topic=currentTopicData();
    addMessage("ai",
      `Hi 👋 Choose your grade and topic above, then ask me what you don’t understand. I’ll keep the answer focused on the learning material for that topic.`,
      topic ? `Grade ${state.selectedGrade} Mathematics • ${topic.name}` : "Mathematics");
  }

  async function sendChat(text){
    const trimmed = text.trim();
    if(!trimmed) return;
    await datasetReady;
    addMessage("user", trimmed);
    const result = tutorResponseFromDataset(trimmed);
    setTimeout(()=> addMessage("ai", result.text, result.source), 180);
  }

  $("#chatForm").addEventListener("submit",e=>{
    e.preventDefault();
    const input=$("#chatInput");
    sendChat(input.value);
    input.value="";
  });

  $("#studyGrade").addEventListener("change",e=>{
    state.selectedGrade = Number(e.target.value);
    const grade=currentGradeData();
    state.selectedTopic=grade.topics[0].id;
    populateTopicSelector();
    updateStudyContext(true);
  });
  $("#studyTopic").addEventListener("change",e=>{
    state.selectedTopic=e.target.value;
    updateStudyContext(true);
  });
  $("#bridgeLanguage").addEventListener("change",e=>{
    state.bridgeLanguage=e.target.value; save(); toast("Language preference updated.");
  });
  $("#tutorMode").addEventListener("change",e=>{
    state.tutorMode=e.target.value; save(); updateStudyContext(false);
  });
  $("#readLastBtn").addEventListener("click",()=>{
    if(!("speechSynthesis" in window)){toast("Read aloud is not supported in this browser.");return;}
    if(!lastAIText){toast("Ask Ubuntu Tutor something first.");return;}
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(lastAIText);
    u.rate = .95;
    speechSynthesis.speak(u);
  });

  function renderQueue(){
    const ql = $("#queueList");
    if(!state.queue.length){
      ql.innerHTML = `<div class="generated-box">You have no saved questions.</div>`;
      return;
    }
    ql.innerHTML = state.queue.map(q=>`<div class="queue-item"><strong>${escapeHtml(q.text)}</strong><small>Saved • ${new Date(q.createdAt).toLocaleString()}</small></div>`).join("");
  }
  $("#viewQueueBtn").addEventListener("click",()=>{renderQueue();openModal("queueModal")});

  // Practice
  const bank = {
    quadratics:[
      {id:"q1", level:"Foundation", text:"Which pair multiplies to +6 and adds to -5?", options:["-2 and -3","2 and 3","-1 and -6","1 and 6"], correct:0, hint:"Because the product is positive and the sum is negative, both numbers should be negative.", tag:"factorisation"},
      {id:"q2", level:"Foundation", text:"Factorise x² - 5x + 6.", options:["(x-2)(x-3)","(x+2)(x+3)","(x-1)(x-6)","(x+1)(x-6)"], correct:0, hint:"Use the pair from the previous question.", tag:"factorisation"},
      {id:"q3", level:"Developing", text:"Factorise x² - 7x + 12.", options:["(x-2)(x-6)","(x-3)(x-4)","(x+3)(x+4)","(x-1)(x-12)"], correct:1, hint:"Find two numbers that multiply to 12 and add to -7.", tag:"signs"},
      {id:"q4", level:"Stretch", text:"Solve (x-3)(x-4)=0.", options:["x=3 or x=4","x=-3 or x=-4","x=7","x=12"], correct:0, hint:"A product is zero if one of its factors is zero.", tag:"quadratics"}
    ],
    signs:[
      {id:"s1",level:"Foundation",text:"What is (-3)(-4)?",options:["12","-12","7","-7"],correct:0,hint:"Same signs when multiplying give a positive answer.",tag:"signs"},
      {id:"s2",level:"Foundation",text:"What is -3 + 8?",options:["5","-5","11","-11"],correct:0,hint:"Compare the sizes: 8 is larger than 3, so the result is positive.",tag:"signs"},
      {id:"s3",level:"Developing",text:"What is 4 - (-6)?",options:["-2","2","10","-10"],correct:2,hint:"Subtracting a negative becomes addition.",tag:"signs"}
    ],
    algebra:[
      {id:"a1",level:"Foundation",text:"Solve: 2x + 4 = 10",options:["x=2","x=3","x=4","x=7"],correct:1,hint:"Subtract 4 first, then divide by 2.",tag:"algebra"},
      {id:"a2",level:"Developing",text:"Expand: 3(x + 2)",options:["3x+2","3x+5","3x+6","x+6"],correct:2,hint:"Multiply 3 by every term inside the bracket.",tag:"algebra"},
      {id:"a3",level:"Developing",text:"If x=4, what is x² - 3?",options:["5","13","16","19"],correct:1,hint:"Square 4 first, then subtract 3.",tag:"algebra"}
    ]
  };

  let session = null;

  function startPractice(){
    const topic = $("#practiceTopic").value;
    session = {
      topic,
      questions:[...bank[topic]].slice(0,3),
      index:0, score:0, confidence:[], currentSelection:null, currentConfidence:null, mistakes:[]
    };
    $("#practiceIntro").classList.add("hidden");
    $("#sessionSummary").classList.add("hidden");
    $("#teachBackStage").classList.add("hidden");
    $("#practiceActive").classList.remove("hidden");
    renderQuestion();
  }

  function renderQuestion(){
    const q = session.questions[session.index];
    $("#questionCounter").textContent = `Question ${session.index+1} of ${session.questions.length}`;
    $("#difficultyBadge").textContent = q.level;
    $("#practiceProgressBar").style.width = `${(session.index/session.questions.length)*100}%`;
    $("#questionText").textContent = q.text;
    $("#answerOptions").innerHTML="";
    $("#confidencePrompt").classList.add("hidden");
    $("#questionFeedback").classList.add("hidden");
    $("#nextQuestionBtn").classList.add("hidden");
    $("#practiceHintBtn").classList.remove("hidden");
    session.currentSelection=null; session.currentConfidence=null;

    q.options.forEach((opt,i)=>{
      const b=document.createElement("button");
      b.className="answer-btn";
      b.textContent=opt;
      b.addEventListener("click",()=>{
        if(session.currentSelection!==null) return;
        session.currentSelection=i;
        $$(".answer-btn").forEach(x=>x.classList.remove("selected"));
        b.classList.add("selected");
        $("#confidencePrompt").classList.remove("hidden");
        $("#practiceHintBtn").classList.add("hidden");
      });
      $("#answerOptions").appendChild(b);
    });
  }

  function chooseConfidence(level,button){
    if(!session || session.currentSelection===null || session.currentConfidence!==null) return;
    session.currentConfidence=Number(level);
    session.confidence.push(Number(level));
    $$(".confidence-buttons button").forEach(b=>b.classList.remove("selected"));
    button.classList.add("selected");

    const q=session.questions[session.index];
    const correct=session.currentSelection===q.correct;
    const buttons=$$(".answer-btn");
    buttons[q.correct].classList.add("correct");
    if(!correct){
      buttons[session.currentSelection].classList.add("wrong");
      session.mistakes.push(q.tag);
    }else session.score++;

    const fb=$("#questionFeedback");
    fb.classList.remove("hidden");
    fb.classList.toggle("error",!correct);
    if(correct && Number(level)<=2){
      fb.innerHTML=`✅ <b>Correct — but Ubuntu noticed low confidence.</b><br>You understand more than you think. We'll keep one short reinforcement task in your next pack.`;
    }else if(correct){
      fb.innerHTML=`✅ <b>Correct.</b><br>Your answer and confidence agree, so Ubuntu can move you forward.`;
    }else{
      fb.innerHTML=`Not quite. <b>${q.hint}</b><br>Ubuntu tagged this as a <b>${prettyTag(q.tag)}</b> pattern and will adapt the next recommendation.`;
    }
    $("#nextQuestionBtn").classList.remove("hidden");
  }

  $$(".confidence-buttons button").forEach(b=>b.addEventListener("click",()=>chooseConfidence(b.dataset.confidence,b)));
  $("#practiceHintBtn").addEventListener("click",()=>{
    if(!session) return;
    const q=session.questions[session.index];
    const fb=$("#questionFeedback");
    fb.classList.remove("hidden");
    fb.classList.remove("error");
    fb.innerHTML=`💡 <b>Hint:</b> ${q.hint}`;
  });
  $("#nextQuestionBtn").addEventListener("click",()=>{
    if(session.index < session.questions.length-1){
      session.index++;
      renderQuestion();
    }else{
      $("#practiceActive").classList.add("hidden");
      $("#teachBackStage").classList.remove("hidden");
    }
  });

  function prettyTag(tag){
    return ({signs:"sign handling",factorisation:"factorisation",quadratics:"quadratic equations",algebra:"basic algebra"})[tag]||tag;
  }

  function checkTeachBack(){
    const text=$("#teachBackInput").value.trim();
    const result=$("#teachBackResult");
    result.classList.remove("hidden","error");
    if(text.length<25){
      result.classList.add("error");
      result.innerHTML=`Give me a little more detail. Mention what the two numbers must <b>multiply to</b> and what they must <b>add to</b>.`;
      return;
    }
    const lower=text.toLowerCase();
    const hasProduct=/(multiply|product|phindaphind|phindaphindeka|12)/.test(lower);
    const hasSum=/(add|sum|hlangan|hlanganiswa|-7|negative seven)/.test(lower);
    const hasPair=/(3|4|three|four)/.test(lower);
    let mastery = [hasProduct,hasSum,hasPair].filter(Boolean).length;
    if(mastery>=2){
      result.innerHTML=`✅ <b>Strong teach-back.</b><br>You explained the relationship between the product and the sum${hasPair ? " and identified the useful factor pair":""}. That is evidence of conceptual understanding, not just answer recognition.<br><br><button class="btn primary" id="finishSessionBtn">Finish session</button>`;
    }else{
      result.classList.add("error");
      result.innerHTML=`You're partly there. A complete explanation should say that we need <b>two numbers that multiply to 12 and add to -7</b>. Try again in your own words.`;
      return;
    }
    $("#finishSessionBtn").addEventListener("click",finishSession);
  }
  $("#checkTeachBackBtn").addEventListener("click",checkTeachBack);

  function finishSession(){
    const avgConf = session.confidence.length ? session.confidence.reduce((a,b)=>a+b,0)/session.confidence.length : 0;
    const mistakeCounts={};
    session.mistakes.forEach(t=>mistakeCounts[t]=(mistakeCounts[t]||0)+1);
    const mainGap = Object.entries(mistakeCounts).sort((a,b)=>b[1]-a[1])[0]?.[0] || "none";

    // Update dynamic metrics.
    const pct = Math.round((session.score/session.questions.length)*100);
    if(session.topic==="quadratics"){
      state.metrics.quadratics=Math.round((state.metrics.quadratics+pct)/2);
      state.metrics.factorisation=Math.min(100,state.metrics.factorisation+(session.score>=2?4:1));
    }
    if(session.topic==="signs") state.metrics.signs=Math.round((state.metrics.signs+pct)/2);
    if(session.topic==="algebra") state.metrics.algebra=Math.round((state.metrics.algebra+pct)/2);

    state.metrics.confidenceAlignment = Math.max(35,Math.min(95,Math.round((avgConf/4)*100)));

    session.mistakes.forEach(tag=>{
      const titleMap={
        signs:"Negative-number sign errors",
        factorisation:"Factorisation concept",
        quadratics:"Quadratic-equation method",
        algebra:"Basic algebra"
      };
      let existing=state.misconceptions.find(m=>m.key===tag);
      if(existing) existing.count++;
      else state.misconceptions.push({key:tag,title:titleMap[tag],detail:"Pattern detected during adaptive practice.",count:1,severity:"medium"});
    });

    state.practiceHistory.push({
      date:new Date().toISOString(),topic:session.topic,score:session.score,total:session.questions.length,avgConfidence:avgConf,mainGap
    });
    state.activity.unshift({
      date:"Just now",
      title:`Adaptive ${prettyTag(session.topic)} session completed`,
      detail:`Score ${session.score}/${session.questions.length}. ${mainGap==="none"?"No major new gap detected.":`Main pattern: ${prettyTag(mainGap)}.`}`
    });
    if(isOffline()) queueSync("practice-session",{topic:session.topic,score:session.score});
    save();
    if(window.UbuntuAuth){
      window.UbuntuAuth.recordProgress({
        metrics: state.metrics,
        misconceptions: state.misconceptions,
        activity: state.activity,
        offline: isOffline()
      });
    }

    $("#teachBackStage").classList.add("hidden");
    $("#sessionSummary").classList.remove("hidden");
    $("#summaryScore").textContent=`${session.score}/${session.questions.length}`;
    $("#summaryConfidence").textContent=avgConf ? `${Math.round((avgConf/4)*100)}%` : "—";
    $("#summaryGap").textContent=mainGap==="none"?"No major gap":prettyTag(mainGap);
    updateLiveFingerprint();
  }

  function updateLiveFingerprint(){
    $("#liveFingerprint").innerHTML=`
      <div class="fp-item good"><span>✓</span><div><b>Basic algebra</b><small>${state.metrics.algebra}% mastery estimate</small></div></div>
      <div class="fp-item warn"><span>↗</span><div><b>Factorisation</b><small>${state.metrics.factorisation}% mastery estimate</small></div></div>
      <div class="fp-item danger"><span>!</span><div><b>Sign handling</b><small>${state.metrics.signs}% mastery estimate</small></div></div>
      <div class="fp-item neutral"><span>?</span><div><b>Confidence</b><small>${state.metrics.confidenceAlignment}% alignment</small></div></div>`;
  }
  $("#startPracticeBtn").addEventListener("click",startPractice);
  $("#practiceTopic").addEventListener("change",()=>{
    $("#practiceIntro").classList.remove("hidden");
    $("#practiceActive").classList.add("hidden");
    $("#teachBackStage").classList.add("hidden");
    $("#sessionSummary").classList.add("hidden");
  });

  // Offline packs
  const packCatalog = [
    {id:"math10t2",icon:"∑",title:"Grade 10 Mathematics • Term 2",size:48,topics:["Quadratics","Functions","Trigonometry"],personalised:true},
    {id:"science10",icon:"⚗",title:"Grade 10 Physical Sciences",size:54,topics:["Mechanics","Matter","Electricity"],personalised:false},
    {id:"math-foundations",icon:"±",title:"Maths Foundations Rescue Pack",size:18,topics:["Negative numbers","Fractions","Algebra"],personalised:true}
  ];

  function packSize(p){ return state.dataSaver ? Math.max(8,Math.round(p.size*.42)) : p.size; }

  function renderPacks(){
    const grid=$("#packGrid");
    grid.innerHTML="";
    packCatalog.forEach(p=>{
      const downloaded=state.packs.includes(p.id);
      const card=document.createElement("article");
      card.className="pack-card";
      card.innerHTML=`
        <div class="pack-top">
          <div class="pack-icon">${p.icon}</div>
          ${p.personalised?'<span class="chip warm">Personalised</span>':'<span class="chip">Curriculum pack</span>'}
        </div>
        <h3>${p.title}</h3>
        <p>${downloaded?"Ready offline. Lessons, examples, hints and quizzes are stored locally.":`About ${packSize(p)} MB ${state.dataSaver?"in Data Saver mode":""}.`}</p>
        <div class="pack-tags">${p.topics.map(x=>`<span>${x}</span>`).join("")}</div>
        <div class="pack-progress"><i style="width:${downloaded?100:0}%"></i></div>
        <div class="pack-actions">
          <button class="btn ${downloaded?"secondary":"primary"} download-pack">${downloaded?"Downloaded ✓":"Download"}</button>
          <button class="btn secondary mesh-share" ${downloaded?"":"disabled"}>Mesh share</button>
        </div>`;
      const download=card.querySelector(".download-pack");
      download.addEventListener("click",()=>simulateDownload(p,card));
      card.querySelector(".mesh-share").addEventListener("click",()=>openMesh(p));
      grid.appendChild(card);
    });
  }

  function simulateDownload(pack,card){
    if(state.packs.includes(pack.id)){toast("This pack is already ready offline.");return;}
    const bar=card.querySelector(".pack-progress i");
    const btn=card.querySelector(".download-pack");
    btn.disabled=true; btn.textContent="Preparing…";
    let pct=0;
    const timer=setInterval(()=>{
      pct+=10+Math.floor(Math.random()*16);
      if(pct>=100){
        pct=100; clearInterval(timer);
        state.packs.push(pack.id);
        state.activity.unshift({date:"Just now",title:"Offline pack prepared",detail:`${pack.title} is ready with personalised/local content.`});
        save();
        renderPacks();
        toast(`${pack.title} is ready offline.`);
      }
      bar.style.width=`${pct}%`;
    },120);
  }

  function openMesh(pack){
    if(!state.packs.includes(pack.id)){toast("Download the pack before sharing it.");return;}
    const code=String(Math.floor(1000+Math.random()*9000));
    $("#meshCode").textContent=code.split("").join(" ");
    $("#meshBigCode").textContent=code;
    openModal("meshModal");
  }
  $("#generateMeshCodeBtn").addEventListener("click",()=>{
    const any=state.packs[0];
    if(!any){toast("Download at least one offline pack first.");return;}
    openMesh(packCatalog.find(p=>p.id===any));
  });
  $("#dataSaverToggle").addEventListener("change",e=>{state.dataSaver=e.target.checked;save();renderPacks();toast(e.target.checked?"Data Saver enabled.":"Data Saver disabled.")});
  $("#forceOfflineToggle").addEventListener("change",e=>{
    state.forceOffline=e.target.checked;
    if(state.forceOffline){
      if(!state.packs.length) toast("Offline mode is on. Download a learning pack for the best experience.");
      else toast("Offline mode is on — your downloaded learning is ready.");
    }else{
      toast("You’re back online.");
      setTimeout(trySync,200);
      setTimeout(()=>window.UbuntuAuth?.flushProgressQueue?.(),250);
    }
    save();
  });

  function updateOfflineBanner(){
    const off=isOffline();
    const b=$("#offlineBanner");
    b.classList.toggle("off",off);
    $("#offlineBannerTitle").textContent=off?"Ubuntu Offline is active.":"You're connected.";
    $("#offlineBannerText").textContent=off
      ? (state.packs.length?`${state.packs.length} downloaded pack${state.packs.length===1?" is":"s are"} available. New activity will queue for sync.`:"No packs downloaded yet. Download a learning pack before going offline.")
      :"Ubuntu can prepare and sync personalised learning packs.";
    $("#offlineBannerChip").textContent=off?"OFFLINE":"ONLINE";
    $("#offlineBannerChip").className=`chip ${off?"warm":"success"}`;
  }

  // Progress page
  function renderProgress(){
    const p=currentProfile();
    $("#fpLearnerName").textContent=`${p.short}'s learning pattern`;
    const m=state.metrics;
    [["Algebra",m.algebra],["Factor",m.factorisation],["Signs",m.signs],["Quadratics",m.quadratics]].forEach(([name,val])=>{
      $(`#skill${name}`).style.width=`${val}%`;
      $(`#skill${name}Text`).textContent=`${val}%`;
    });
    $("#confidenceScore").textContent=`${m.confidenceAlignment}%`;

    const mis=$("#misconceptionList");
    mis.innerHTML=state.misconceptions.length?state.misconceptions
      .sort((a,b)=>b.count-a.count)
      .map(x=>`<div class="misconception"><strong>${escapeHtml(x.title)}</strong><span>${escapeHtml(x.detail)} • Seen ${x.count} time${x.count===1?"":"s"}.</span></div>`).join("")
      :`<div class="misconception"><strong>No major patterns yet</strong><span>Complete practice sessions to build the fingerprint.</span></div>`;

    const recommendations=[];
    if(m.signs<60) recommendations.push(["5-minute negative-number rescue","Do this before more factorisation so sign errors don't hide your actual understanding."]);
    if(m.factorisation<70) recommendations.push(["Factorisation mini-lesson","Use visual factor pairs, then answer 3 adaptive questions."]);
    if(m.confidenceAlignment<70) recommendations.push(["Confidence-building check","Repeat 2 questions you previously answered correctly but with low confidence."]);
    if(!recommendations.length) recommendations.push(["Ready to progress","Move to a harder quadratic-equations set."]);
    $("#recommendationList").innerHTML=recommendations.map(r=>`<div class="recommendation"><strong>${r[0]}</strong><span>${r[1]}</span></div>`).join("");

    $("#activityTimeline").innerHTML=state.activity.slice(0,7).map(a=>`
      <div class="timeline-item"><div class="timeline-date">${escapeHtml(a.date)}</div><div class="timeline-dot"><i></i></div><div class="timeline-content"><b>${escapeHtml(a.title)}</b><span>${escapeHtml(a.detail)}</span></div></div>
    `).join("");
  }

  $("#resetDemoDataBtn").addEventListener("click",()=>{
    if(!confirm("Reset your learning data and downloaded packs?")) return;
    const profiles=state.profiles;
    state=clone(defaultState);
    state.profiles=profiles;
    state.activeProfileId=profiles[0].id;
    save();renderPacks();renderProgress();updateLiveFingerprint();toast("Demo learning data reset.");
  });

  // Teacher
  $("#generateInterventionBtn")?.addEventListener("click",()=>{
    const box=$("#generatedIntervention");
    box.classList.remove("hidden");
    box.innerHTML=`
      <b>15-minute Sign-Error Rescue</b><br>
      <b>1. Warm-up (3 min):</b> 5 rapid same-sign / different-sign multiplication questions.<br>
      <b>2. Pair explain (4 min):</b> Learners explain why (-3)(-4) is positive.<br>
      <b>3. Apply (5 min):</b> Factorise x² - 7x + 12 and highlight the sign decision.<br>
      <b>4. Exit check (3 min):</b> One question + confidence rating.<br><br>
      This activity can be saved inside the class offline pack.`;
    toast("Classroom intervention generated.");
  });

  // Helpers
  function escapeHtml(str=""){
    return String(str).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
  }

  window.UbuntuSetLearnerGrade = function(grade){
    const g = Number(grade);
    if(!mathDataset || !mathDataset.grades.some(x=>x.grade===g)) return;
    state.selectedGrade = g;
    const block = currentGradeData();
    state.selectedTopic = block.topics[0].id;
    populateStudySelectors();
    updateStudyContext(false);
  };

  // PWA
  if("serviceWorker" in navigator){
    window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
  }

  // Initial render
  datasetReady = loadMathDataset();
  initChat();
  renderProfiles();
  renderPacks();
  renderProgress();
  updateLiveFingerprint();
  updateGlobalUI();
  window.dispatchEvent(new Event("ubuntu-app-ready"));
})();

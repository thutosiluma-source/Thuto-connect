# Ubuntu Tutor V6.1 — FIXED BUILD

This build fixes the Grade/Topic dropdown issue shown in the screenshot.

The cause was a JavaScript runtime error that stopped the Mathematics dataset from initialising. The dataset is now also loaded directly as a bundled JavaScript file, so the Grade and Topic selectors do not depend on a separate browser fetch.

Run this build on **port 8035** to avoid any older cached build.

# Ubuntu Tutor V6

This build focuses on the learner experience and a Mathematics learning dataset.

## What changed

- The app still starts on sign in / registration.
- Teacher registration, teacher QR joining, independent learners, adding students and individual student analytics are still included.
- The learner tutor now has a **Subject / Grade / Topic** learning context.
- The prototype subject is **Mathematics**.
- Grades **8–12** have a local Mathematics learning library.
- Tutor answers are generated from the selected grade/topic record in `data/math_dataset.json`.
- Each topic contains:
  - overview
  - key rules
  - worked examples
  - common mistakes
  - practice question
  - hint
  - suggested questions
- The tutor shows the selected source context below its answers.
- The interface was cleaned up so learners see learning controls rather than prototype/backend explanations.
- One-click learner and teacher demo buttons were added to the sign-in page.
- Technical LAN/link information was removed from the visible teacher QR card.
- Offline caching includes the Mathematics dataset.

## Run

On Windows, double-click:

`run_windows.bat`

Or run:

`python server.py --port 8035`

Open:

`http://localhost:8035`

## Demo accounts

You can use the **Try learner demo** and **Try teacher demo** buttons on the sign-in screen.

Teacher registration school code for the demo:

`UBUNTU2026`

## Strong demo flow

1. Click **Try learner demo**.
2. Open **Ubuntu Tutor**.
3. Select **Grade 10 → Quadratic equations**.
4. Ask: `How do I solve x² - 5x + 6 = 0?`
5. Change the topic to **Factorisation** and ask: `How do I know which signs go in the brackets?`
6. Change the grade to show that the topic list changes with the grade.
7. Turn on **Offline mode** and ask another question from the selected topic.
8. Sign out and use **Try teacher demo**.
9. Select individual learners to show their analytics.
